﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ismétlés3.Program;

namespace ismétlés3
{
    internal class Program
    {
        internal class Macska
        {
            public string Nev { get; set; }
            public int Eletkor { get; set; }
        }

        internal class Kutya

        {
            public string Nev { get; set; }
            public int Eletkor { get; set; }

            public Kutya(string kezdoNev, int kezdoEletkor)
            {
                Nev = kezdoNev;
                Eletkor = kezdoEletkor;
            }
            public Kutya(string kezdoNev)
            {
                Nev = kezdoNev;
            }
            public Kutya()
            {

            }
            public void Kiir()
            {
                Console.WriteLine($"A kutya neve: {Nev}, életkora: {Eletkor} év.");
            }


        }
        static void Main(string[] args)
        {
            Macska macska1 = new Macska();

            macska1.Nev = "Cili";
            macska1.Eletkor = 5;

            Macska macska2 = new Macska();
            macska2.Nev = "Molly";
            macska2.Eletkor = 6;


            Console.WriteLine(macska1.Nev);
            Console.WriteLine(macska2.Nev);
            Console.WriteLine(macska2.Eletkor);
            Console.WriteLine($"A macska neve {macska1.Nev} életkora {macska1.Eletkor} év!");

            Kutya kutya1 = new Kutya("Jerry", 5);
            Console.WriteLine(kutya1);
            Console.WriteLine(kutya1.Nev);
            Console.WriteLine(kutya1.Eletkor);

            Kutya kutya2 = new Kutya("Raffi", 4);
            Console.WriteLine(kutya2.Nev);

            Console.WriteLine($"A kutya neve {kutya1.Nev} életkora {kutya1.Eletkor} év!");

            Kutya kutya3 = new Kutya("Jessy", 3);
            Console.WriteLine(kutya3.Nev);
            Console.WriteLine(kutya3.Eletkor);

            kutya1.Kiir();
            kutya2.Kiir();
            kutya3.Kiir();



        }
        static void Kiir(Kutya kutya)
        {
            Console.WriteLine($"A kutya neve {kutya.Nev} életkora {kutya.Eletkor} év!");
        }


    }
}
