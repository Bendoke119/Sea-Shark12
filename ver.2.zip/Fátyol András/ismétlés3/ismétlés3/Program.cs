﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ismétlés3.Program;

namespace ismétlés3
{
    internal class Program
    {
        internal class Macska
        {
            public string Nev { get; set; }
            public int Eletkor { get; set; }
        }

        internal class Kutya

        {
            public string Nev { get; set; }
            public int Eletkor { get; set; }

            public Kutya(string kezdoNev, int kezdoEletkor)
            {
                Nev = kezdoNev;
                Eletkor = kezdoEletkor;
            }
            public Kutya(string kezdoNev)
            {
                Nev = kezdoNev;
            }
            public Kutya()
            {

            }
            public void Kiir()
            {
                Console.WriteLine($"A kutya neve: {Nev}, életkora: {Eletkor} év.");
            }


        }

        internal class Gyumolcs

        {
            public string Nev { get; set; }
            public string Szin { get; set; }

            public Gyumolcs(string kezdoNev, string kezdoSzin)
            {
                Nev = kezdoNev;
                Szin = kezdoSzin;

            }
            public void Kiir()
            {
                Console.WriteLine($"A gyumolcs neve: {Nev}, szine {Szin} .");
            }
        }

        static void Main(string[] args)
        {
            Macska macska1 = new Macska();

            macska1.Nev = "Cili";
            macska1.Eletkor = 5;

            Macska macska2 = new Macska();
            macska2.Nev = "Molly";
            macska2.Eletkor = 6;


            Console.WriteLine(macska1.Nev);
            Console.WriteLine(macska2.Nev);
            Console.WriteLine(macska2.Eletkor);
            Console.WriteLine($"A macska neve {macska1.Nev} életkora {macska1.Eletkor} év!");

            Kutya kutya1 = new Kutya("Jerry", 5);
            Console.WriteLine(kutya1);
            Console.WriteLine(kutya1.Nev);
            Console.WriteLine(kutya1.Eletkor);

            Kutya kutya2 = new Kutya("Raffi", 4);
            Console.WriteLine(kutya2.Nev);

            Console.WriteLine($"A kutya neve {kutya1.Nev} életkora {kutya1.Eletkor} év!");

            Kutya kutya3 = new Kutya("Jessy", 3);
            Console.WriteLine(kutya3.Nev);
            Console.WriteLine(kutya3.Eletkor);

            kutya1.Kiir();
            kutya2.Kiir();
            kutya3.Kiir();

            Gyumolcs gy1 = new Gyumolcs("alma", "piros");
            Gyumolcs gy2 = new Gyumolcs("szilva", "kék");
            Gyumolcs gy3 = new Gyumolcs("barack", "sárga");
            Gyumolcs gy4 = new Gyumolcs("banán", "sárga");

            Gyumolcs[] gyumolcsok = { gy1, gy2, gy3, gy4 };

            Console.WriteLine(gyumolcsok[0].Nev);


            for (int i = 0; i < 5; i++)
            {

                Console.WriteLine(gy1.Nev);
            }

            for (int i = 0; i < gyumolcsok.Length; i++)
            {
                Console.WriteLine(gyumolcsok[i].Nev);
            }

            for (int i = 0; i < gyumolcsok.Length; i++)
            {
                Console.Write(gyumolcsok[i].Nev + " ");
                Console.WriteLine(gyumolcsok[i].Szin);

            }

            List<Gyumolcs> gyumolcs = new List<Gyumolcs>();

            gyumolcs.Add(gy1);
            gyumolcs.Add(gy2);
            gyumolcs.Add(gy3);
            gyumolcs.Add(gy4);

            for (int i = 0; i < gyumolcs.Count; i++)
            {
                Console.WriteLine($"{gyumolcs[i].Nev} {gyumolcs[i].Szin}");
            }

            foreach (Gyumolcs i in gyumolcsok)
            {
                Console.WriteLine($"{i.Nev} {i.Szin}");
            }


        }
        static void Kiir(Kutya kutya)
        {
            Console.WriteLine($"A kutya neve {kutya.Nev} életkora {kutya.Eletkor} év!");
        }


    }
}
