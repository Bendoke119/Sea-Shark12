﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Hapci()
        {
            Console.WriteLine("Hapci");
        }
        static void Cskala(string nev, int cmeter)
        {
            Console.WriteLine(nev + " ennyire C: " + cmeter);
        }
        static void menu()
        {
            int a = 5;
            int b = 10;
            int c = 15;
            
            Console.WriteLine("\nMit szeretnél csinálni? (adj meg egy számot)\n");
            Console.WriteLine("1. Számok megjelenítése\n");
            Console.WriteLine("2. számok összeadás\n");
            Console.WriteLine("3. kilépés\n");
            int v = Convert.ToInt32(Console.ReadLine());
           
        if (v == 1)
        {
                    
            Console.WriteLine("A: " + a + " B: " + b + " C: " + c );
            menu();
        }
        else if (v == 2)
        {
            Console.WriteLine("Összegük: " + (a + b + c));
            menu();
        }
        else if (v == 3)
        {
            Console.WriteLine("Kilépés...");
                    
        }
            else
        {
            menu();
        }
            
        }
        class nevek
        {
            string vezeteknev;
            string keresztnev;

            static void neve()
            {
                nevek Bela = new nevek();
                Bela.vezeteknev = "Kovács";
                Bela.keresztnev = "Béla";
                Console.WriteLine(Bela.keresztnev);
            }
           
        }
            static void Main(string[] args)
            {
                /*
                Console.WriteLine("Hello Bello");

                string nev = "Csikánó";
                Console.WriteLine(nev);

                int szam1 = 5;
                int szam2 = 2;

                Console.WriteLine("Ez az első szám: "+szam1);
                Console.WriteLine("Ez a második szám: "+szam2);
                Console.WriteLine();
                Console.WriteLine("Szorzatuk:");
                int szorzat = szam1 * szam2;
                Console.WriteLine(szorzat);

                if (szorzat > 10)
                {
                    Console.WriteLine("A szorzat több mint tíz");
                }
                else if (szorzat < 10)
                {
                    Console.WriteLine("A szorzat kevesebb mint tíz");
                }
                else
                {
                    Console.WriteLine("A szorzat egyenlő tízzel");
                }

                int wsz = 0;
                while (wsz < 10)
                {
                    wsz++;
                    Console.WriteLine(wsz);
                }

                for (int i = 1; i < 6; i++)
                {
                    Console.WriteLine(i);
                }
                Hapci();
                Console.WriteLine();
                Cskala("Brendon", 10);
                Cskala("Dzsennáró", 9);
                Cskala("Dávid", 5);
                */

                menu();

                /*string[] nevek = { "Béla", "Méla", "Béna" };
                foreach (string nev in nevek)
                {
                    Console.WriteLine(nev);
                }
                */

                


            }

        
    }
}
